## DIU - Practica1, entregables




- Desk research: Análisis Competencia 
- 2 Personas 
- 2 User Journey Map  ( 1 por persona)
- Revisión de Usabilidad 


(valoración y conclusiones de esta etapa)
